Requires 1060netkernel-x.x.x.jar, 1060netkernel-embedded-x.x.x.jar and all jars from lib/endorsed
copied into this directory